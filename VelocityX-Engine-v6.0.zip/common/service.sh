#!/bin/sh
#kalau mau ambil ya minimal credit lah cok @sirNumeX

read_file() {
  if [ -f "$1" ]; then
    if [ ! -r "$1" ]; then
      chmod +r "$1"
    fi
    cat "$1"
  fi
}
write_file() {
  if [ -f "$1" ]; then
    if [ ! -w "$1" ]; then
      chmod +w "$1"
    fi
    echo "$2" > "$1"
  fi
}

sleep 60

if [ ! -d "/data/media/0/Android/VelocityX-E/" ]; then
   mkdir /data/media/0/Android/VelocityX-E/
fi

function get_busybox_dir() {
   BUSYBOX=$(find /data/adb/ -type f -name busybox | head -n 1)
}
function set_log_dir() {
   LOG=/data/media/0/Android/VelocityX-E/fstrim.log
}
function empty_debug_log() {
   echo "" > $LOG
   echo "START FSTRIM [$(date +"%Y-%m-%d %T")] >> " >> $LOG
}
function run_fstrim_debug() {
   $BUSYBOX fstrim -v $1 >> $LOG
}

get_busybox_dir
set_log_dir
empty_debug_log

run_fstrim_debug /system
run_fstrim_debug /vendor
run_fstrim_debug /metadata
run_fstrim_debug /odm
run_fstrim_debug /system_ext
run_fstrim_debug /data
run_fstrim_debug /cache

while [ -z "$(resetprop sys.boot_completed)" ]; do
    sleep 5
done

if [ "$(wc -c </data/adb/modules/VXE/module.prop)" -eq 317 ]; then
   su -lp 2000 -c "cmd notification post -S bigtext -t 'VelocityX Engine' 'Tag' 'Starting Configuration.'"

   chmod 000 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
   chmod 000 /sys/devices/system/cpu/cpu1/cpufreq/cpuinfo_max_freq
   chmod 000 /sys/devices/system/cpu/cpu2/cpufreq/cpuinfo_max_freq
   chmod 000 /sys/devices/system/cpu/cpu3/cpufreq/cpuinfo_max_freq
   chmod 000 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
   chmod 000 /sys/devices/system/cpu/cpu5/cpufreq/cpuinfo_max_freq
   chmod 000 /sys/devices/system/cpu/cpu6/cpufreq/cpuinfo_max_freq
   chmod 000 /sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq
   chmod 000 /sys/devices/system/cpu/cpu0/cpu_capacity
   chmod 000 /sys/devices/system/cpu/cpu1/cpu_capacity
   chmod 000 /sys/devices/system/cpu/cpu2/cpu_capacity
   chmod 000 /sys/devices/system/cpu/cpu3/cpu_capacity
   chmod 000 /sys/devices/system/cpu/cpu4/cpu_capacity
   chmod 000 /sys/devices/system/cpu/cpu5/cpu_capacity
   chmod 000 /sys/devices/system/cpu/cpu6/cpu_capacity
   chmod 000 /sys/devices/system/cpu/cpu7/cpu_capacity
   chmod 000 /sys/devices/system/cpu/cpu0/topology/physical_package_id
   chmod 000 /sys/devices/system/cpu/cpu1/topology/physical_package_id
   chmod 000 /sys/devices/system/cpu/cpu2/topology/physical_package_id
   chmod 000 /sys/devices/system/cpu/cpu3/topology/physical_package_id
   chmod 000 /sys/devices/system/cpu/cpu4/topology/physical_package_id
   chmod 000 /sys/devices/system/cpu/cpu5/topology/physical_package_id
   chmod 000 /sys/devices/system/cpu/cpu6/topology/physical_package_id
   chmod 000 /sys/devices/system/cpu/cpu7/topology/physical_package_id
   
   for gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
      write_file "gov" "performance"
   done
   
   chmod 644 /sys/module/workqueue/parameters/power_efficient
   write_file "/sys/module/workqueue/parameters/power_efficient" "Y"
   write_file "/sys/kernel/gpu/gpu_governor" "performance"
   write_file "/sys/class/kgsl/kgsl-3d0/devfreq/governor" "performance"
   write_file "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" "performance"
   write_file "/sys/devices/system/cpu/cpu1/cpufreq/scaling_governor" "performance"
   write_file "/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor" "performance"
   write_file "/sys/devices/system/cpu/cpu3/cpufreq/scaling_governor" "performance"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/scaling_governor" "performance"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/scaling_boost_frequencies" "1555200"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/performance/up_rate_limit_us" "3000"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/performance/down_rate_limit_us" "200"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/performance/hispeed_load" "100"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/performance/go_hispeed_load" "100"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq" "902400"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/scaling_setspeed" "always_support"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/scaling_governor" "performance"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/scaling_boost_frequencies" "2016000"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/performance/up_rate_limit_us" "4000"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/performance/down_rate_limit_us" "200"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/performance/hispeed_load" "100"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/performance/go_hispeed_load" "100"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq" "1113600"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed" "always_support"
   write_file "/sys/devices/system/cpu/cpufreq/policy6/scaling_setspeed" "always_support"
   write_file "/sys/devices/system/cpu/cpufreq/performance/go_hispeed_load" "100"
   write_file "/sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay" "0"
   write_file "/sys/devices/system/cpu/cpufreq/performance/boost" "1"
   write_file "/sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis" "1"
   write_file "/sys/devices/system/cpu/cpufreq/performance/align_windows" "1"
   write_file "/sys/module/adreno_idler/parameters/adreno_idler_active" "0"
   write_file "/sys/module/lazyplug/parameters/nr_possible_cores" "8"
   write_file "/dev/cpuset/foreground/boost/cpus" "6-7"
   write_file "/dev/cpuset/foreground/cpus" "2-3,6-7"
   write_file "/dev/cpuset/top-app/cpus" "0-7"
   write_file "/dev/cpuset/audio-app/cpus" "0-7"
   write_file "/dev/cpuset/background/cpus" "0-7"
   write_file "/dev/cpuset/camera-daemon/cpus" "0-7"
   write_file "/dev/cpuset/rt/cpus" "0-7"
   write_file "/sys/devices/system/cpu/isolated" "0"
   write_file "/sys/devices/system/cpu/offline" "0"
   write_file "/sys/devices/system/cpu/uevent" "0"
   write_file "/sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable" "1"
   write_file "/sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable" "1"
   write_file "/sys/devices/system/cpu/cpu0/sched_mostly_idle_freq" "0"
   write_file "/sys/devices/system/cpu/cpu1/sched_mostly_idle_freq" "0"
   write_file "/sys/devices/system/cpu/cpu2/sched_mostly_idle_freq" "0"
   write_file "/sys/devices/system/cpu/cpu3/sched_mostly_idle_freq" "0"
   write_file "/sys/devices/system/cpu/cpu4/sched_mostly_idle_freq" "0"
   write_file "/sys/devices/system/cpu/cpu5/sched_mostly_idle_freq" "0"
   write_file "/sys/devices/system/cpu/cpu6/sched_mostly_idle_freq" "0"
   write_file "/sys/devices/system/cpu/cpu7/sched_mostly_idle_freq" "0"
   
   write_file "/sys/module/cpu_boost/parameters/topkek_boost_freq" "0:0 4:0"
   write_file "/sys/module/cpu_boost/parameters/topkek_boost_ms" "100"
   write_file "/sys/module/cpu_boost/parameters/indelete_boost_freq" "0:1324800 2:1324800"
   write_file "/sys/module/cpu_boost/parameters/indelete_boost_ms" "100"
   write_file "/sys/module/cpu_boost/parameters/indelete_boost_duration" "0"
   write_file "/sys/module/cpu_boost/parameters/dynamic_stune_boost_duration" "0"
   write_file "/sys/module/cpu_boost/parameters/dynamic_stune_boost" "80"
   write_file "/sys/module/gpu_boost/parameters/topkek_boost_freq" "0:0 4:0"
   write_file "/sys/module/gpu_boost/parameters/topkek_boost_ms" "100"
   write_file "/sys/module/gpu_boost/parameters/indelete_boost_freq" "0:1324800 2:1324800"
   write_file "/sys/module/gpu_boost/parameters/indelete_boost_ms" "100"
   write_file "/sys/module/gpu_boost/parameters/indelete_boost_duration" "0"
   write_file "/sys/module/gpu_boost/parameters/dynamic_stune_boost_duration" "0"
   write_file "/sys/module/gpu_boost/parameters/dynamic_stune_boost" "80"
   
   write_file "/proc/sys/kernel/panic" "0"
   write_file "/proc/sys/kernel/panic_on_oops" "0"
   write_file "/proc/sys/kernel/panic_on_rcu_stall" "0"
   write_file "/proc/sys/kernel/panic_on_warn" "0"
   write_file "/proc/sys/kernel/softlockup_panic" "0"
   write_file "/sys/module/kernel/parameters/panic" "0"
   write_file "/sys/module/kernel/parameters/panic_on_warn" "0"
   write_file "/sys/module/kernel/parameters/panic_on_oops" "0"
   
   write_file "/proc/sys/kernel/printk" "0 0 0 0"
   write_file "/proc/sys/kernel/printk_devkmsg" "off"
   write_file "/sys/module/printk/parameters/console_suspend" "Y"
   write_file "/sys/module/printk/parameters/cpu" "N"
   write_file "/sys/module/printk/parameters/ignore_loglevel" "Y"
   write_file "/sys/module/printk/parameters/pid" "N"
   write_file "/sys/module/printk/parameters/time" "N"
   write_file "/sys/kernel/printk_mode/printk_mode" "0"

   write_file "/sys/kernel/debug/sched_features" "NO_GENTLE_FAIR_SLEEPERS:1 START_DEBIT:1 NEXT_BUDDY:1 LAST_BUDDY:1 STRICT_SKIP_BUDDY:1 CACHE_HOT_BUDDY:1 WAKEUP_PREEMPTION:1 NO_HRTICK:1 NO_DOUBLE_TICK:1 LB_BIAS:1 NONTASK_CAPACITY:1 NO_TTWU_QUEUE:1 NO_SIS_AVG_CPU:1 RT_PUSH_IPI:1 NO_FORCE_SD_OVERLAP:1 NO_RT_RUNTIME_SHARE:1 NO_LB_MIN:1 ATTACH_AGE_LOAD:1 ENERGY_AWARE:1 NO_MIN_CAPACITY_CAPPING:1 NO_FBT_STRICT_ORDER:1 EAS_USE_NEED_IDLE:1"
   
   for file1 in $(find /sys/ -type f -name "*log*" -o -name "*debug*" -o -name "*throttling*"); do
      write_file "$file1" "0"
   done
   
   write_file "/sys/devices/system/cpu/cpu0/cpufreq/busfreq_static" "0"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/awake_ideal_freq" "800000"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/sleep_ideal_freq" "200000"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/sleep_wakeup_freq" "800000"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/max_cpu_load" "100"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/min_cpu_load" "55"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/ramp_up_step" "0"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/ramp_down_step" "0"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/up_rate_us" "24000"
   write_file "/sys/devices/system/cpu/cpufreq/smartass/down_rate_us" "99000"
   write_file "/sys/devices/system/cpu/sched_mc_power_savings" "0"
   write_file "/sys/class/misc/gpu_control/gpu_staycount" "1 1 1"

   write_file "/sys/devices/system/cpu/cpufreq/performance/up_threshold" "75"
   write_file "/sys/devices/system/cpu/cpufreq/performance/sampling_rate" "40000"
   write_file "/sys/devices/system/cpu/cpufreq/performance/sampling_down_factor" "5"
   write_file "/sys/devices/system/cpu/cpufreq/performance/down_threshold" "20"
   write_file "/sys/devices/system/cpu/cpufreq/performance/freq_step" "25"
   write_file "/sys/block/sda/queue/scheduler" "deadline"
   write_file "/sys/block/sda/queue/iostats" "0"
   write_file "/sys/block/sda/queue/add_random" "0"
   write_file "/sys/block/sda/queue/read_ahead_kb" "256"
   write_file "/sys/block/sda/queue/nr_requests" "128"
   write_file "/sys/block/sdb/queue/scheduler" "deadline"
   write_file "/sys/block/sdb/queue/add_random" "0"
   write_file "/sys/block/sdb/queue/iostats" "0"
   write_file "/sys/block/sdb/queue/read_ahead_kb" "256"
   write_file "/sys/block/sdb/queue/nr_requests" "128"
   write_file "/sys/block/sdc/queue/scheduler" "deadline"
   write_file "/sys/block/sdc/queue/add_random" "0"
   write_file "/sys/block/sdc/queue/iostats" "0"
   write_file "/sys/block/sdc/queue/read_ahead_kb" "256"
   write_file "/sys/block/sdc/queue/nr_requests" "128"
   write_file "/sys/block/sdd/queue/scheduler" "deadline"
   write_file "/sys/block/sdd/queue/add_random" "0"
   write_file "/sys/block/sdd/queue/iostats" "0"
   write_file "/sys/block/sdd/queue/read_ahead_kb" "256"
   write_file "/sys/block/sdd/queue/nr_requests" "128"
   write_file "/sys/block/sde/queue/scheduler" "deadline"
   write_file "/sys/block/sde/queue/add_random" "0"
   write_file "/sys/block/sde/queue/iostats" "0"
   write_file "/sys/block/sde/queue/read_ahead_kb" "256"
   write_file "/sys/block/sde/queue/nr_requests" "128"
   write_file "/sys/block/sdf/queue/scheduler" "deadline"
   write_file "/sys/block/sdf/queue/add_random" "0"
   write_file "/sys/block/sdf/queue/iostats" "0"
   write_file "/sys/block/sdf/queue/read_ahead_kb" "256"
   write_file "/sys/block/sdf/queue/nr_requests" "128"
   write_file "/sys/block/mmcblk1/queue/scheduler" "deadline"
   write_file "/sys/block/mmcblk1/queue/iostats" "0"
   write_file "/sys/block/mmcblk1/queue/add_random" "0"
   write_file "/sys/block/mmcblk1/queue/read_ahead_kb" "256"
   write_file "/sys/block/mmcblk1/queue/nr_requests" "128"
   write_file "/sys/block/mmcblk0/queue/scheduler" "deadline"
   write_file "/sys/block/mmcblk0/queue/iostats" "0"
   write_file "/sys/block/mmcblk0/queue/add_random" "0"
   write_file "/sys/block/mmcblk0/queue/read_ahead_kb" "256"
   write_file "/sys/block/mmcblk0/queue/nr_requests" "128"

   write_file "/sys/devices/virtual/bdi/179:0/read_ahead_kb" "512"
   
   #kalau mau ambil ya minimal credit lah cok @sirNumeX
   
   write_file "/proc/sys/kernel/sched_tunable_scaling" "1"
   write_file "/sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost" "1"
   write_file "/sys/module/msm_performance/parameters/touchboost" "0"
   write_file "/sys/devices/system/cpu/cpu0/core_ctl/enable" "1"
   write_file "/sys/devices/system/cpu/cpu1/core_ctl/enable" "1"
   write_file "/sys/devices/system/cpu/cpu2/core_ctl/enable" "1"
   write_file "/sys/devices/system/cpu/cpu3/core_ctl/enable" "1"
   write_file "/sys/devices/system/cpu/cpu4/core_ctl/enable" "1"
   write_file "/sys/devices/system/cpu/cpu5/core_ctl/enable" "1"
   write_file "/sys/devices/system/cpu/cpu6/core_ctl/enable" "1"
   write_file "/sys/devices/system/cpu/cpu7/core_ctl/enable" "1"
   write_file "/proc/sys/kernel/perf_event_max_sample_rate" "400000"
   write_file "/proc/sys/kernel/perf_cpu_time_max_percent" "100"
   write_file "/proc/sys/kernel/perf_event_max_contexts_per_stack" "128"
   write_file "/proc/sys/kernel/perf_event_mlock_kb" "4000"
   write_file "/proc/sys/kernel/perf_event_paranoid" "-1"

   write_file "/proc/sys/vm/drop_caches" "3"
   write_file "/proc/sys/vm/dirty_background_ratio" "20"
   write_file "/proc/sys/vm/dirty_expire_centisecs" "1000"
   write_file "/proc/sys/vm/page-cluster" "0"
   write_file "/proc/sys/vm/dirty_ratio" "10"
   write_file "/proc/sys/vm/swap_ratio_enable" "1"
   write_file "/proc/sys/vm/swap_ratio" "200"
   write_file "/proc/sys/vm/laptop_mode" "0"
   write_file "/proc/sys/vm/block_dump" "1"
   write_file "/proc/sys/vm/compact_memory" "0"
   write_file "/proc/sys/vm/dirty_writeback_centisecs" "5000"
   write_file "/proc/sys/vm/oom_dump_tasks" "1"
   write_file "/proc/sys/vm/oom_kill_allocating_task" "0"
   write_file "/proc/sys/vm/stat_interval" "60"
   write_file "/proc/sys/vm/panic_on_oom" "0"
   write_file "/proc/sys/vm/swappiness" "20"
   write_file "/proc/sys/vm/vfs_cache_pressure" "50"
   write_file "/proc/sys/vm/overcommit_ratio" "80"
   write_file "/proc/sys/vm/extra_free_kbytes" "10240"
   write_file "/proc/sys/kernel/random/read_wakeup_threshold" "64"
   write_file "/proc/sys/kernel/random/write_wakeup_threshold" "128"

   android_properties="
      debug.sf.nobootanimation=1
      debug.sf.disable_backpressure=1
      debug.sf.latch_unsignaled=1
      debug.sf.enable_hwc_vds=0
      debug.sf.enable_advanced_sf_phase_offset=1
      debug.sf.early_phase_offset_ns=1000000
      debug.sf.early_app_phase_offset_ns=1000000
      debug.sf.early_gl_phase_offset_ns=3000000
      debug.sf.early_gl_app_phase_offset_ns=15000000
      debug.sf.high_fps_early_phase_offset_ns=6100000
      debug.sf.high_fps_early_gl_phase_offset_ns=6500000
      debug.sf.high_fps_late_app_phase_offset_ns=1000000
      debug.sf.phase_offset_threshold_for_next_vsync_ns=6100000
      debug.sf.showupdates=0
      debug.sf.showcpu=0
      debug.sf.showbackground=0 
      debug.sf.showfps=0
      debug.sf.hw=1
   "
   echo "$android_properties" | while IFS= read -r prop; do
      prop_name="${prop%%=*}"
      prop_value="${prop#*=}"
      resetprop -n "$prop_name" "$prop_value"
   done
  
   for lowm in /sys/module/lowmemorykiller/parameters; do
      write_file "$lowm/minfree" "5120,6144,7168,8192,9216,10240"
      write_file "$lowm/enable_adaptive_lmk" "0"
   done

   if [ -d "/sys/devices/system/cpu/cpu0" ]; then
      max_freq_0=$(read_file "/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   fi
   if [ -d "/sys/devices/system/cpu/cpu1" ]; then
      max_freq_1=$(read_file "/sys/devices/system/cpu/cpu1/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   fi
   if [ -d "/sys/devices/system/cpu/cpu2" ]; then
      max_freq_2=$(read_file "/sys/devices/system/cpu/cpu2/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   fi
   if [ -d "/sys/devices/system/cpu/cpu3" ]; then
      max_freq_3=$(read_file "/sys/devices/system/cpu/cpu3/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   fi
   if [ -d "/sys/devices/system/cpu/cpu4" ]; then
      max_freq_4=$(read_file "/sys/devices/system/cpu/cpu4/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   fi
   if [ -d "/sys/devices/system/cpu/cpu5" ]; then
      max_freq_5=$(read_file "/sys/devices/system/cpu/cpu5/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   fi
   if [ -d "/sys/devices/system/cpu/cpu6" ]; then
      max_freq_6=$(read_file "/sys/devices/system/cpu/cpu6/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   fi
   if [ -d "/sys/devices/system/cpu/cpu7" ]; then
      max_freq_7=$(read_file "/sys/devices/system/cpu/cpu7/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   fi
   max_clock_gpu=$(read_file "/sys/kernel/gpu/gpu_freq_table" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)
   max_clock_kgsl=$(read_file "/sys/class/kgsl/kgsl-3d0/freq_table_mhz" | tr " " "\n" | sort -n | sed "/^$/d" | tail -n 1)

   write_file "/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq" "$max_freq_0"
   write_file "/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq" "$max_freq_0"
   write_file "/sys/devices/system/cpu/cpu1/cpufreq/scaling_min_freq" "$max_freq_1"
   write_file "/sys/devices/system/cpu/cpu1/cpufreq/scaling_max_freq" "$max_freq_1"
   write_file "/sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq" "$max_freq_2"
   write_file "/sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq" "$max_freq_2"
   write_file "/sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq" "$max_freq_3"
   write_file "/sys/devices/system/cpu/cpu3/cpufreq/scaling_max_freq" "$max_freq_3"
   write_file "/sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq" "$max_freq_4"
   write_file "/sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq" "$max_freq_4"
   write_file "/sys/devices/system/cpu/cpu5/cpufreq/scaling_min_freq" "$max_freq_5"
   write_file "/sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq" "$max_freq_5"
   write_file "/sys/devices/system/cpu/cpu6/cpufreq/scaling_min_freq" "$max_freq_6"
   write_file "/sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq" "$max_freq_6"
   write_file "/sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq" "$max_freq_7"
   write_file "/sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq" "$max_freq_7"
   write_file "/sys/kernel/gpu/gpu_min_clock" "$max_clock_gpu"
   write_file "/sys/kernel/gpu/gpu_max_clock" "$max_clock_gpu"
   write_file "/sys/class/kgsl/kgsl-3d0/min_clock_mhz" "$max_clock_kgsl"
   write_file "/sys/class/kgsl/kgsl-3d0/max_clock_mhz" "$max_clock_kgsl"
   write_file "/sys/class/kgsl/kgsl-3d0/throttling" "0"
   
   cmd thermalservice override-status 0
   cmd power set-fixed-performance-mode-enabled true
   cmd activity kill-all
   
   su -lp 2000 -c "cmd notification post -S bigtext -t 'VelocityX Engine' 'Tag' 'Successfully Runing.'"
else
   reboot
fi