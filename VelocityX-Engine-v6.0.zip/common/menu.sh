if [ ! -e "/data/media/0/Android/VelocityX-E/jitcontroller.log" ]; then
  touch /data/media/0/Android/VelocityX-E/jitcontroller.log
fi
LOG=/data/media/0/Android/VelocityX-E/jitcontroller.log
package_list=$(cmd package list packages -3 | cut -f 2 -d ":")

function cache_cleaner() {
    clear
    echo "\033[1;31m
            ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▄▄▄▄▄▄▄▄▒▒▒▒▒▒▒
            ▒▒▒█▒▒▒▄██████████▄▒▒▒▒▒
            ▒▒█▐▒▒▒████████████▒▒▒▒▒
            ▒▒▌▐▒▒██▄▀██████▀▄██▒▒▒▒
            ▒▐┼▐▒▒██▄▄▄▄██▄▄▄▄██▒▒▒▒
            ▒▐┼▐▒▒██████████████▒▒▒▒
            ▒▐▄▐████─▀▐▐▀█─█─▌▐██▄▒▒
            ▒▒▒█████──────────▐███▌▒
            ▒▒▒█▀▀██▄█─▄───▐─▄███▀▒▒
            ▒▒▒█▒▒███████▄██████▒▒▒▒
            ▒▒▒▒▒▒██████████████▒▒▒▒
            ▒▒▒▒▒▒██████████████▒▒▒▒
            ▒▒▒▒▒▒█████████▐▌██▌▒▒▒▒
            ▒▒▒▒▒▒▐▀▐▒▌▀█▀▒▐▒█▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▒▒▒▐▒▒▒▒▌▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
          \033[1;33mAuthor   >>  \033[1;37m@sirNumeX
          \033[1;33mSource   >>  \033[1;37mhttps://t.me/NumeXSource
    "
    echo "\033[1;36m======================================================="
    echo "\033[1;32m###############\033[1;33m 𝗖𝗔𝗖𝗛𝗘 𝗖𝗟𝗘𝗔𝗡𝗘𝗥 𝗨𝗡𝗜𝗩𝗘𝗥𝗦𝗔𝗟 \033[1;32m###############"
    echo "\033[1;36m======================================================="
    echo ""
    echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;33mFinding cache file..."
    echo ""
    
    # Internal Cache
    internal_cache_size1=$(find /data/media/*/Android/data/*/cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    internal_cache_size2=$(find /sdcard/Android/data/*/cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    total_internal_cache_size=$(echo "$internal_cache_size1 + $internal_cache_size2" | bc)
    echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;33mInternal Cache Found \033[1;32m>> \033[1;37m${total_internal_cache_size} MB"
    
    # External Cache
    external_cache_size=$(find /mnt/media_rw/*/Android/data/*/cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;33mExternal Cache Found \033[1;32m>> \033[1;37m${external_cache_size} MB"
    
    # System Cache
    system_cache_size1=$(find /data/data/*/cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    system_cache_size2=$(find /data/data/*/code_cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    system_cache_size3=$(find /data_mirror/data_ce/null/0/*/cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    system_cache_size4=$(find /data_mirror/data_de/null/0/*/cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    system_cache_size5=$(find /data/user_de/*/*/cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    system_cache_size6=$(find /data/user_de/*/*/code_cache/* -exec du -ch {} + 2>/dev/null | awk '/total$/ {sum += $1} END {print sum + 0}')
    total_system_cache_size=$(echo "$system_cache_size1 + $system_cache_size2 + $system_cache_size3 + $system_cache_size4 + $system_cache_size5 + $system_cache_size6" | bc)
    echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;33mSystem Cache Found \033[1;32m>> \033[1;37m${total_system_cache_size} MB"
    
    # Delete Internal, External, System Cache
    find /storage/emulated/0/ -type d -empty -delete >/dev/null 2>&1
    find /data/media/*/Android/data/*/cache/* -delete >/dev/null 2>&1
    find /sdcard/Android/data/*/cache/* -delete >/dev/null 2>&1
    find /mnt/media_rw/*/Android/data/*/cache/* -delete >/dev/null 2>&1
    find /data/data/*/cache/* -delete >/dev/null 2>&1
    find /data/data/*/code_cache/* -delete >/dev/null 2>&1
    find /data_mirror/data_ce/null/*/*/cache/* -delete >/dev/null 2>&1
    find /data_mirror/data_de/null/*/*/cache/* -delete >/dev/null 2>&1
    find /data/user_de/*/*/cache/* -delete >/dev/null 2>&1
    find /data/user_de/*/*/code_cache/* -delete >/dev/null 2>&1
    
    echo ""
    echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;33mCache Has Been Cleared \033[1;32mSuccessfully"
    echo ""
    sleep 4
}

function show_menu() {
  echo "\033[1;31m
            ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▄▄▄▄▄▄▄▄▒▒▒▒▒▒▒
            ▒▒▒█▒▒▒▄██████████▄▒▒▒▒▒
            ▒▒█▐▒▒▒████████████▒▒▒▒▒
            ▒▒▌▐▒▒██▄▀██████▀▄██▒▒▒▒
            ▒▐┼▐▒▒██▄▄▄▄██▄▄▄▄██▒▒▒▒
            ▒▐┼▐▒▒██████████████▒▒▒▒
            ▒▐▄▐████─▀▐▐▀█─█─▌▐██▄▒▒
            ▒▒▒█████──────────▐███▌▒
            ▒▒▒█▀▀██▄█─▄───▐─▄███▀▒▒
            ▒▒▒█▒▒███████▄██████▒▒▒▒
            ▒▒▒▒▒▒██████████████▒▒▒▒
            ▒▒▒▒▒▒██████████████▒▒▒▒
            ▒▒▒▒▒▒█████████▐▌██▌▒▒▒▒
            ▒▒▒▒▒▒▐▀▐▒▌▀█▀▒▐▒█▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▒▒▒▐▒▒▒▒▌▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
          \033[1;33mAuthor   >>  \033[1;37m@sirNumeX
          \033[1;33mSource   >>  \033[1;37mhttps://t.me/NumeXSource
    "
  echo "\033[1;36m======================================================="
  echo "\033[1;32m###############\033[1;33m 𝗝𝗨𝗦𝗧 𝗜𝗧 𝗧𝗜𝗠𝗘 𝗖𝗢𝗡𝗧𝗥𝗢𝗟𝗟𝗘𝗥 \033[1;32m###############"
  echo "\033[1;36m======================================================="
  echo ""
  echo "\033[1;32mPilih Aplikasi yang akan digunakan Just In Time"
  count=1
  for package in $package_list; do
    echo "\033[1;32m[\033[1;36m$count\033[1;32m] \033[1;33m$package"
    ((count++))
  done
  echo "\033[1;32m[\033[1;36m$count\033[1;32m] \033[1;33mKeluar"
}

function jit_controller() {
   while true; do
      clear
      show_menu
      echo ""
      echo -n "\033[1;32m[\033[1;37m?\033[1;32m] \033[1;33mPilih Nomor \033[1;32m>> \033[1;37m"
      read choice
      if [ "$choice" == $(($count)) ]; then
        echo ""
        exit 0
      elif [ "$choice" -ge 1 ] && [ "$choice" -lt $(($count)) ]; then
        select_package=$(echo $package_list | cut -d ' ' -f $choice)
        echo ""
        echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
        echo ""
        echo "\n\033[1;32m[## \033[1;36mMenu Just In Time \033[1;32m##]"
        echo "\033[1;32m[\033[1;36m1\033[1;32m] \033[1;33mRevert"
        echo "\033[1;32m[\033[1;36m2\033[1;32m] \033[1;33mRegular"
        echo "\033[1;32m[\033[1;36m3\033[1;32m] \033[1;33mTurbo"
        echo "\033[1;32m[\033[1;36m4\033[1;32m] \033[1;33mExtreme"
        echo ""
        echo -n "\033[1;32m[\033[1;37m?\033[1;32m] \033[1;33mPilih Mode [1-4] \033[1;32m>> \033[1;37m"
        read mode_choice

        case $mode_choice in
           1)
             sleep 2
             echo ""
             echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
             echo ""
             echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;32mReverting mode for package $select_package"
             echo ""
             sleep 2
             echo "$select_package | revert" >> $LOG
             cmd package compile -m verify -f "$select_package" > /dev/null 2>&1 && echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;32mSuccessfully" && sed -i "/$select_package/d" $LOG || echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;31mFailed"
             echo ""
             sleep 5
             ;;
           2)
             sleep 2
             echo ""
             echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
             echo ""
             echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;32mOptimizing $select_package  >> Regular Mode"
             echo ""
             sleep 2
             sed -i "/$select_package/d" $LOG
             cmd package compile -m speed-profile -f "$select_package" > /dev/null 2>&1 && echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;32mSuccessfully" && echo "$select_package | Regular" >> $LOG || echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;31mFailed"
             echo ""
             sleep 5
             ;;
           3)
             sleep 2
             echo ""
             echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
             echo ""
             echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;32mOptimizing $select_package >> Turbo Mode"
             echo ""
             sleep 2
             sed -i "/$select_package/d" $LOG
             cmd package compile -m speed -f "$select_package" > /dev/null 2>&1 && echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;32mSuccessfully" && echo "$select_package | Turbo" >> $LOG || echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;31mFailed"
             echo ""
             sleep 5
             ;;
           4)
             sleep 2
             echo ""
             echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
             echo ""
             echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;32mOptimizing $select_package >> Extreme Mode"
             echo ""
             sleep 2
             sed -i "/$select_package/d" $LOG
             cmd package compile -m everything -f "$select_package" > /dev/null 2>&1 && echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;32mSuccessfully" && echo "$select_package | Extreme" >> $LOG || echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;31mFailed"
             echo ""
             sleep 5
             ;;
           *)
            jit_controller
            ;;
        esac
      else
        echo ""
        echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
        echo ""
        echo "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;31mPilihan tidak valid. Silakan pilih nomor [1-4]"
        sleep 2
      fi
        echo
   done
}

while true; do
  clear
  echo "\033[1;31m
            ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▄▄▄▄▄▄▄▄▒▒▒▒▒▒▒
            ▒▒▒█▒▒▒▄██████████▄▒▒▒▒▒
            ▒▒█▐▒▒▒████████████▒▒▒▒▒
            ▒▒▌▐▒▒██▄▀██████▀▄██▒▒▒▒
            ▒▐┼▐▒▒██▄▄▄▄██▄▄▄▄██▒▒▒▒
            ▒▐┼▐▒▒██████████████▒▒▒▒
            ▒▐▄▐████─▀▐▐▀█─█─▌▐██▄▒▒
            ▒▒▒█████──────────▐███▌▒
            ▒▒▒█▀▀██▄█─▄───▐─▄███▀▒▒
            ▒▒▒█▒▒███████▄██████▒▒▒▒
            ▒▒▒▒▒▒██████████████▒▒▒▒
            ▒▒▒▒▒▒██████████████▒▒▒▒
            ▒▒▒▒▒▒█████████▐▌██▌▒▒▒▒
            ▒▒▒▒▒▒▐▀▐▒▌▀█▀▒▐▒█▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▒▒▒▐▒▒▒▒▌▒▒▒▒▒▒
            ▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒
          \033[1;33mAuthor   >>  \033[1;37m@sirNumeX
          \033[1;33mSource   >>  \033[1;37mhttps://t.me/NumeXSource
  "
  echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
  echo "\n\033[1;32m[## \033[1;36mMenu VelocityX-Engine \033[1;32m##]"
  echo "\033[1;32m[\033[1;36m1\033[1;32m] \033[1;33mCache Cleaner"
  echo "\033[1;32m[\033[1;36m2\033[1;32m] \033[1;33mJIT Controller"
  echo "\033[1;32m[\033[1;36m3\033[1;32m] \033[1;33mKeluar"
  echo ""
  echo -n "\033[1;32m[\033[1;37m?\033[1;32m] \033[1;33mPilih Opsi [1-3] \033[1;32m>> \033[1;37m"
  read option

  case $option in
    1)
      cache_cleaner
      ;;
    2)
      jit_controller
      ;;
    3)
      echo ""
      echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
      echo ""
      echo -e "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;31mKeluar dari program...\n"
      exit 0
      ;;
    *)
      echo ""
      echo "\033[1;36m[\033[1;32m######################################################\033[1;36m]"
      echo ""
      echo -e "\033[1;32m[\033[1;36m=>\033[1;32m] \033[1;31mOpsi tidak valid. Silakan pilih Opsi [1-3]\n"
      sleep 2
      ;;
  esac
done

